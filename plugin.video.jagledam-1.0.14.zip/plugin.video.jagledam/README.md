# JaGledam TV for Kodi 21.x

Dynamic Kodi video add-on for browsing JaGledam channels by country and choosing individual stream links.

## Install
1. Copy `plugin.video.jagledam-1.0.0.zip` to a location Kodi can access.
2. Kodi -> Add-ons -> Install from zip file.
3. Open Video add-ons -> JaGledam TV.

## Design
- No TV stream URLs are bundled in the add-on.
- Country/channel/stream pages are requested at browse/play time.
- Multiple `Stream Link N` entries are shown individually.
- The resolver follows ordinary public iframe/media references and passes the resulting media URL to Kodi.
- It intentionally contains no DRM, login, paywall, token-generation, or access-control bypass.

## Troubleshooting
If the site changes its HTML/player implementation, enable Kodi debug logging and inspect entries containing `JaGledam`.
