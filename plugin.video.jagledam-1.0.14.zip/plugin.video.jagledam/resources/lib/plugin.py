# -*- coding: utf-8 -*-
import re
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
from . import site

HANDLE=int(sys.argv[1]); BASE=sys.argv[0]

def url(**kw): return BASE+'?'+urllib.parse.urlencode(kw)
def add_folder(label, **kw):
    li=xbmcgui.ListItem(label=label); li.setProperty('IsPlayable','false')
    xbmcplugin.addDirectoryItem(HANDLE,url(**kw),li,True)
def add_play(label, **kw):
    li=xbmcgui.ListItem(label=label); li.setProperty('IsPlayable','true')
    li.setInfo('video',{'title':label,'mediatype':'video'})
    xbmcplugin.addDirectoryItem(HANDLE,url(**kw),li,False)
def finish():
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.endOfDirectory(HANDLE,cacheToDisc=False)
def notify(msg): xbmcgui.Dialog().notification('JaGledam TV',msg,xbmcgui.NOTIFICATION_ERROR,6000)

def _ia_enabled():
    try:
        return (xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
                and xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'))
    except Exception:
        return xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')

def _headers_str(ref, mode='full'):
    parts={
        'User-Agent': site.UA,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.8',
    }
    if ref and mode != 'noref':
        parts['Referer']=ref
        m=re.match(r'(https?://[^/]+)', ref)
        if m: parts['Origin']=m.group(1)
    return urllib.parse.urlencode(parts)

def root():
    for label,code,keys in site.COUNTRIES: add_folder(label,mode='country',code=code)
    finish()
def country(code):
    try: channels=site.discover_channels(code)
    except Exception as e: notify('Could not load channels: '+str(e)); channels=[]
    for ch in channels:
        li=xbmcgui.ListItem(label=ch['name']); li.setProperty('IsPlayable','false')
        if ch.get('image'): li.setArt({'thumb': ch['image'], 'icon': ch['image']})
        xbmcplugin.addDirectoryItem(HANDLE,url(mode='channel',page=ch['url']),li,True)
    if not channels: add_folder('[No channels discovered - site layout may have changed]',mode='noop')
    finish()
def channel(page):
    try: choices=site.stream_choices(page)
    except Exception as e: notify('Could not load streams: '+str(e)); choices=[]
    for c in choices: add_play(c['name'],mode='play',stream=c['url'],referer=c['referer'],page=page)
    if not choices: add_folder('[No stream links found]',mode='noop')
    finish()

def _resolve_media(stream, referer, page):
    """Resolve to a direct media URL. If the first choice fails (JaGledam
    tokens expire fast), re-scrape the channel page and try fresh choices."""
    attempts=[(stream, referer)]
    if page:
        try:
            for c in site.stream_choices(page):
                if c['url'] != stream:
                    attempts.append((c['url'], c['referer']))
        except Exception as e:
            xbmc.log('JaGledam re-scrape of %s failed: %r' % (page, e), xbmc.LOGDEBUG)
    last_err=None
    for choice_url, ref in attempts[:4]:
        try:
            media, mref, drm, mode = site.resolve(choice_url, ref)
            return media, mref, drm, mode
        except Exception as e:
            xbmc.log('JaGledam resolve failed for %s: %r' % (choice_url, e), xbmc.LOGDEBUG)
            last_err=e
    raise RuntimeError(str(last_err) if last_err else 'No resolvable stream found')

def play(stream, referer, page):
    if not _ia_enabled():
        notify('InputStream Adaptive add-on is missing or disabled')
        xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem()); return
    try:
        media, ref, drm, mode = _resolve_media(stream, referer, page)
    except Exception as e:
        xbmc.log('JaGledam resolve error: %r' % e, xbmc.LOGERROR)
        notify('Stream could not be resolved: '+str(e))
        xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem()); return

    headers=_headers_str(ref, mode)
    # Pass the website session cookies along: many CDNs 403 without them.
    ck=site.cookies_for(media)
    if ck:
        headers += '&' + urllib.parse.urlencode({'Cookie': ck})
        xbmc.log('JaGledam: sending %d bytes of cookies for %s' % (len(ck), media), xbmc.LOGDEBUG)
    path=media+'|'+headers
    li=xbmcgui.ListItem(path=path)
    li.setProperty('IsPlayable','true')
    li.setContentLookup(False)
    xbmc.log('JaGledam resolved stream: %s (ref=%s)' % (media, ref), xbmc.LOGINFO)

    low=media.lower()
    stem=low.split('?')[0]
    is_hls = (stem.endswith('.m3u8')
              or any(x in low for x in ('player=m3u8','format=m3u8','type=m3u8','type=hls','ext=m3u8')))
    is_mpd = (stem.endswith('.mpd')
              or any(x in low for x in ('player=mpd','format=mpd','type=mpd','type=dash','ext=mpd')))
    if is_hls:
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setProperty('inputstream','inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type','hls')
        li.setProperty('inputstream.adaptive.manifest_headers',headers)
        li.setProperty('inputstream.adaptive.stream_headers',headers)
    elif is_mpd:
        li.setMimeType('application/dash+xml')
        li.setProperty('inputstream','inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type','mpd')
        li.setProperty('inputstream.adaptive.manifest_headers',headers)
        li.setProperty('inputstream.adaptive.stream_headers',headers)
    elif stem.endswith(('.mp4','.m4v','.webm')):
        li.setMimeType('video/mp4')

    # DRM: hand the license configuration (extracted from the player page) to IA.
    # ClearKey must use drm_legacy (license_type/license_key do NOT support it).
    # Format: org.w3.clearkey|kid1:key1,kid2:key2  (hex values)
    if drm and drm.get('scheme'):
        if drm.get('keys'):
            # Inline ClearKeys (Shaka-style) – preferred path for Hayat etc.
            li.setProperty('inputstream.adaptive.drm_legacy',
                           'org.w3.clearkey|%s' % drm['keys'])
        elif drm.get('license'):
            # License-server based DRM (Widevine / PlayReady / ClearKey URL)
            li.setProperty('inputstream.adaptive.license_type', drm['scheme'])
            li.setProperty('inputstream.adaptive.license_key',
                           drm['license']+'|'+headers+'|R{SSM}|')
            # Also set drm_legacy for newer IA versions
            li.setProperty('inputstream.adaptive.drm_legacy',
                           '%s|%s' % (drm['scheme'], drm['license']))
        xbmc.log('JaGledam: DRM scheme=%s license=%s' % (
            drm['scheme'], drm.get('license') or drm.get('keys') or '(NONE FOUND)'), xbmc.LOGINFO)

    xbmcplugin.setResolvedUrl(HANDLE,True,li)

def run():
    q=urllib.parse.parse_qs(sys.argv[2][1:] if len(sys.argv)>2 else '')
    g=lambda k,d='': q.get(k,[d])[0]
    mode=g('mode')
    if not mode: root()
    elif mode=='country': country(g('code'))
    elif mode=='channel': channel(g('page'))
    elif mode=='play': play(g('stream'),g('referer'),g('page'))
    else: finish()
