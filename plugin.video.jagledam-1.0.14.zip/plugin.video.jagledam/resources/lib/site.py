# -*- coding: utf-8 -*-
import base64
import html
import json
import re
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar
from html.parser import HTMLParser

BASE = 'https://www.jagledam.cc'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'

_COOKIE_JAR = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(_COOKIE_JAR))

COUNTRIES = [
    ('Bosnia & Herzegovina', 'BIH', ('bih', 'bosna', 'bosnia')),
    ('Croatia', 'HR', ('hr', 'hrvatska', 'croatia')),
    ('Serbia', 'RS', ('rs', 'srbija', 'serbia')),
    ('Slovenia', 'SLO', ('slo', 'slovenija', 'slovenia')),
    ('Montenegro', 'CG', ('cg', 'crna gora', 'montenegro')),
    ('North Macedonia', 'MK', ('mk', 'makedonija', 'macedonia')),
    ('Kosovo', 'KS', ('ks', 'kosovo')),
]

MEDIA_EXT_RE = re.compile(r'(?i)\.(?:m3u8|mpd|mp4|m4v|webm|m4s|ts)(?:\?|#|$)')


def _dbg(msg):
    """Log to the Kodi log when running inside Kodi, else stdout."""
    try:
        import xbmc
        xbmc.log('JaGledam: %s' % msg, xbmc.LOGDEBUG)
    except Exception:
        print('JaGledam:', msg)


class ResolveError(Exception):
    """Raised when a stream choice cannot be turned into a direct media URL."""


class Links(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links=[]; self._a=None; self._text=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if tag.lower()=='a' and d.get('href'):
            self._a=d; self._text=[]
    def handle_data(self, data):
        if self._a is not None: self._text.append(data)
    def handle_endtag(self, tag):
        if tag.lower()=='a' and self._a is not None:
            self.links.append((dclean(' '.join(self._text)), self._a.get('href',''), self._a))
            self._a=None; self._text=[]


def dclean(s):
    return re.sub(r'\s+', ' ', html.unescape(s or '')).strip()


def absolute(url, base=BASE):
    return urllib.parse.urljoin(base, html.unescape(url or ''))


def fetch(url, referer=None):
    headers={
        'User-Agent':UA,
        'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language':'en-US,en;q=0.8',
        'Cache-Control':'no-cache',
    }
    if referer: headers['Referer']=referer
    req=urllib.request.Request(url, headers=headers)
    with _OPENER.open(req, timeout=20) as r:
        raw=r.read()
        enc=r.headers.get_content_charset() or 'utf-8'
        return raw.decode(enc, 'replace'), r.geturl()


def links_from(doc):
    p=Links(); p.feed(doc); return p.links


def is_jagledam_embed(url):
    p=urllib.parse.urlparse(url)
    return p.netloc.lower().endswith('jagledam.cc') and re.match(r'^/k\d+/',p.path or '') is not None


def _is_home(url):
    p=urllib.parse.urlparse(url)
    return p.netloc.lower().endswith('jagledam.cc') and (p.path or '/') in ('','/')


def cookies_for(url):
    """Cookie header string for the URL's domain from the shared cookie jar."""
    try:
        req=urllib.request.Request(url)
        _COOKIE_JAR.add_cookie_header(req)
        return req.get_header('Cookie') or ''
    except Exception:
        return ''


def check_media(url, ref):
    """Probe a media URL with the headers IA will use.

    Some CDNs/WAFs silently drop connections that carry a foreign Referer
    (timeout instead of 403), so on failure we retry without Referer/Origin.

    Returns (ok, status, content_type, snippet, mode); mode is 'full' (with
    Referer) or 'noref' (without) for a successful probe, None on failure."""
    full={'User-Agent':UA,'Accept':'*/*'}
    if ref:
        full['Referer']=ref
        m=re.match(r'(https?://[^/]+)', ref)
        if m: full['Origin']=m.group(1)
    noref={'User-Agent':UA,'Accept':'*/*','Accept-Language':'en-US,en;q=0.8'}
    last=(False, None, '', b'')
    for mode, headers in (('full', full), ('noref', noref)):
        try:
            req=urllib.request.Request(url, headers=headers)
            with _OPENER.open(req, timeout=10) as r:
                data=r.read(4096)
                return True, getattr(r,'status',200), r.headers.get('Content-Type',''), data[:2048], mode
        except urllib.error.HTTPError as e:
            try: body=e.read(200)
            except Exception: body=b''
            last=(False, e.code, e.headers.get('Content-Type','') if e.headers else '', body)
        except Exception as e:
            last=(False, None, '', str(e).encode())
    return last[0], last[1], last[2], last[3], None


# Common Encryption / DRM system identifiers (hex prefixes of the UUIDs).
_DRM_SYSTEM_IDS = (
    ('edef8ba9', 'widevine'),
    ('9a04f079', 'playready'),
    ('e2719d58', 'clearkey'),
)

_LICENSE_KEY_RE = re.compile(r'(?i)["\']?(?:serverURL|server_url|licenseURL|license_url|licenseServer|license_server|laurl|licenseUri|license_uri)["\']?\s*[:=]\s*["\'](https?://[^"\']+)')

_LICENSE_TYPE_BY_SCHEME = {
    'widevine': 'com.widevine.alpha',
    'playready': 'com.microsoft.playready',
    'clearkey': 'org.w3.clearkey',
}


def manifest_encrypted(body):
    """Detect the DRM scheme inside a manifest (bytes/str), or None if clear."""
    if not body:
        return None
    if isinstance(body, bytes):
        try: body = body.decode('utf-8', 'replace')
        except Exception: return 'unknown'
    low = body.lower()
    if ('contentprotection' in low or '#ext-x-key' in low
            or 'ext-x-session-key' in low):
        for sid, name in _DRM_SYSTEM_IDS:
            if sid in low:
                return name
        if 'widevine' in low: return 'widevine'
        if 'playready' in low: return 'playready'
        if 'clearkey' in low or 'org.w3.clearkey' in low: return 'clearkey'
        if '#ext-x-key' in low: return 'aes-128'  # IA handles this natively
        return 'unknown'
    return None


def manifest_key_uri(body):
    """Extract the license/key URI from an HLS manifest's #EXT-X-KEY lines."""
    if not body:
        return None
    if isinstance(body, bytes):
        try: body = body.decode('utf-8', 'replace')
        except Exception: return None
    m = re.search(r'(?i)#EXT-X-KEY:[^\n]*?URI=["\']([^"\']+)', body)
    return html.unescape(m.group(1)) if m else None


def _scheme_from_text(low):
    if 'com.widevine.alpha' in low or 'widevine' in low:
        return 'com.widevine.alpha'
    if 'com.microsoft.playready' in low or 'playready' in low:
        return 'com.microsoft.playready'
    if 'org.w3.clearkey' in low or 'clearkey' in low:
        return 'org.w3.clearkey'
    return None


_CLEARKEY_OBJ_RE = re.compile(r'(?is)"keys"\s*:\s*\[\s*\{(?P<o>[^{}]*?)\}')
_CK_K_RE = re.compile(r'(?is)"k"\s*:\s*"([A-Za-z0-9_\-+/=]+)"')
_CK_KID_RE = re.compile(r'(?is)"kid"\s*:\s*"([A-Za-z0-9_\-+/=]+)"')
# Shaka Player style: clearKeys: { 'kidhex':'keyhex', 'kid2':'key2', ... }
_SHAKA_CLEARKEYS_RE = re.compile(
    r'(?is)clearKeys\s*:\s*\{([^{}]+)\}'
)
_SHAKA_KID_KEY_RE = re.compile(
    r'''['"]([0-9a-fA-F]{32})['"]\s*:\s*['"]([0-9a-fA-F]{32})['"]'''
)
# JWPlayer style: clearkey: { "keyId": "hex", "key": "hex" }
_JW_CLEARKEY_RE = re.compile(
    r'''(?is)clearkey\s*:\s*\{[^{}]*?["']keyId["']\s*:\s*["']([0-9a-fA-F]{32})["']\s*,\s*["']key["']\s*:\s*["']([0-9a-fA-F]{32})["']'''
)
# Also accept reversed key/keyId order
_JW_CLEARKEY_RE2 = re.compile(
    r'''(?is)clearkey\s*:\s*\{[^{}]*?["']key["']\s*:\s*["']([0-9a-fA-F]{32})["']\s*,\s*["']keyId["']\s*:\s*["']([0-9a-fA-F]{32})["']'''
)

# (scheme, url) extraction patterns covering common players:
# shaka ("servers" map), dash.js ("protectionData"/serverURL), clappr-drm,
# and direct "scheme": "https://lic..." assignments.
_SCHEME_URL_PATTERNS = [
    r'(?is)["\'](com\.widevine\.alpha|com\.microsoft\.playready|org\.w3\.clearkey)["\']\s*[:=]\s*(?:\{[^}]*?server(?:URL)?\s*[:=]\s*)?["\'](https?://[^"\'\s}<>]+)',
    r'(?is)servers\s*:\s*\{[^}]*?["\'](com\.widevine\.alpha|com\.microsoft\.playready|org\.w3\.clearkey)["\']\s*:\s*["\'](https?://[^"\'<>}]+)',
    r'(?is)(com\.widevine\.alpha|com\.microsoft\.playready|org\.w3\.clearkey).{0,400}?serverURL["\']?\s*[:=]\s*["\'](https?://[^"\'<>}]+)',
]

_LICENSE_ENDPOINT_RE = re.compile(r'(?i)https?://[^"\'<>\s]*(?:widevine|playready|clearkey|license|drm)[^"\'<>\s]*')


def drm_config(doc, base):
    """Extract DRM configuration from a player page, if present.

    Returns a dict with keys:
      'scheme'  - IA license_type string (com.widevine.alpha, ...)
      'license' - license server URL ('' if unknown)
      'keys'    - ClearKey 'kid:key' material ('' if not ClearKey)
    or None when the page has no DRM config at all.
    """
    found = {}
    keys = ''
    bodies = list(_decoded_variants(doc))
    # Unpack base64-obfuscated JS configs (atob('...')) and scan them too.
    extra = []
    for body in bodies:
        for b64 in re.findall(r'atob\(\s*["\']([A-Za-z0-9+/=]{24,})["\']\s*\)', body):
            try:
                extra.append(base64.b64decode(b64).decode('utf-8', 'replace'))
            except Exception:
                pass
    bodies += extra

    for body in bodies:
        low = body.lower()
        page_scheme = _scheme_from_text(low)
        urls = []
        for pat in _SCHEME_URL_PATTERNS:
            for m in re.finditer(pat, body):
                urls.append((m.group(1).lower(), html.unescape(m.group(2))))
        for u in _LICENSE_KEY_RE.findall(body):
            urls.append((page_scheme, html.unescape(u)))
        # Heuristic: any URL that looks like a license endpoint on a page
        # which mentions a DRM scheme.
        if page_scheme:
            for u in _LICENSE_ENDPOINT_RE.findall(body):
                urls.append((page_scheme, html.unescape(u)))
        for scheme, u in urls:
            if scheme and scheme not in found:
                found[scheme] = urllib.parse.urljoin(base, u)
        # ClearKey with inline keys: {"keys":[{"kty":"oct","k":"..","kid":".."}]}
        if not keys:
            for m in _CLEARKEY_OBJ_RE.finditer(body):
                o = m.group('o')
                km = _CK_K_RE.search(o)
                kidm = _CK_KID_RE.search(o)
                if km and kidm:
                    keys = '%s:%s' % (kidm.group(1), km.group(1))
                    break
        # Shaka Player clearKeys map: { 'kid':'key', 'kid2':'key2', ... }
        # Collect ALL pairs – multi-period live MPDs often rotate keys.
        if not keys:
            pairs = []
            for m in _SHAKA_CLEARKEYS_RE.finditer(body):
                for kid, key in _SHAKA_KID_KEY_RE.findall(m.group(1)):
                    pairs.append('%s:%s' % (kid.lower(), key.lower()))
            if pairs:
                keys = ','.join(pairs)
        # JWPlayer: clearkey: { "keyId": "hex", "key": "hex" }
        if not keys:
            pairs = []
            for m in _JW_CLEARKEY_RE.finditer(body):
                pairs.append('%s:%s' % (m.group(1).lower(), m.group(2).lower()))
            for m in _JW_CLEARKEY_RE2.finditer(body):
                # group1=key, group2=keyId (reversed order)
                pairs.append('%s:%s' % (m.group(2).lower(), m.group(1).lower()))
            if pairs:
                keys = ','.join(pairs)

    if not found and not keys:
        return None
    out = {}
    if found:
        scheme = list(found.keys())[0]
        out['scheme'] = scheme
        out['license'] = found[scheme]
    if keys:
        # Inline ClearKeys take priority over a Widevine scheme detected
        # only from ContentProtection in the manifest / page text.
        out['scheme'] = 'org.w3.clearkey'
        out['license'] = out.get('license', '')
        out['keys'] = keys
    return out

def _decoded_variants(doc):
    """Return common JS/HTML decoded variants without executing JavaScript."""
    vals=[doc]
    try: vals.append(html.unescape(doc))
    except Exception: pass
    more=[]
    for v in vals:
        more.append(v.replace('\\/','/').replace('\\u002F','/').replace('\\u002f','/').replace('\\x2F','/').replace('\\x2f','/'))
    return unique_urls(vals+more)


def unique_urls(seq):
    out=[]; seen=set()
    for x in seq:
        x=html.unescape(x).replace('\\/','/').strip().strip('"\'')
        if x and x not in seen: seen.add(x); out.append(x)
    return out


def _looks_like_media(u):
    """Accept classic extensions OR query-style HLS/DASH endpoints."""
    if MEDIA_EXT_RE.search(u):
        return True
    low = u.lower()
    # Common patterns used by CDNs that don't put .m3u8/.mpd in the path
    if any(x in low for x in (
        'player=m3u8', 'format=m3u8', 'type=m3u8', 'type=hls',
        'player=mpd', 'format=mpd', 'type=mpd', 'type=dash',
        '/playlist.m3u8', '/manifest.mpd', 'ext=m3u8', 'ext=mpd',
    )):
        return True
    return False


def media_urls(doc, base):
    """Extract direct media URLs (.m3u8/.mpd/.mp4/...) from HTML/JS player pages."""
    good=[]
    for body in _decoded_variants(doc):
        vals=[]
        # Absolute URLs ending in a media extension (query strings allowed).
        vals += re.findall(r'(?i)https?://[^\s"\'<>\\)]+?\.(?:m3u8|mpd|mp4|m4v|webm|m4s)(?:\?[^\s"\'<>\\)]*)?', body)
        # Quoted relative/absolute values assigned to common player keys
        # (jwplayer "file:", clappr "source:", generic "src/hls/stream:").
        # Also match unquoted JS identifiers:  const source = "..."
        for p in [
            r'(?i)["\'](?:file|src|source|url|hls|stream|playlist|manifest|videoUrl|video_url|file_url|fileUrl|m3u8)["\']?\s*[:=]\s*["\']([^"\']+)',
            r'(?i)(?:^|[;\s{])(?:const|let|var)?\s*(?:file|src|source|url|hls|stream|playlist|manifest|videoUrl|video_url|file_url|fileUrl|m3u8)\s*[:=]\s*["\']([^"\']+)',
            r'(?is)<(?:source|video)\b[^>]*?\bsrc\s*=\s*["\']([^"\']+)',
        ]:
            vals += re.findall(p, body)
        # Base64-obfuscated URLs (atob('...')).
        for b64 in re.findall(r'atob\(\s*["\']([A-Za-z0-9+/=]+)["\']\s*\)', body):
            try:
                dec=base64.b64decode(b64).decode('utf-8','replace')
                vals += re.findall(r'(?i)https?://[^\s"\'<>\\)]+', dec)
            except Exception:
                pass
        for v in vals:
            u=absolute(html.unescape(v).replace('\\/','/'),base)
            if _looks_like_media(u):
                good.append(u)
    return unique_urls(good)


def player_candidates(doc, base):
    vals=[]
    for body in _decoded_variants(doc):
        vals += extract_iframes(body, base)
        patterns=[
            r'(?i)(?:window\.)?location(?:\.href)?\s*=\s*["\']([^"\']+)',
            r'(?i)location\.replace\(\s*["\']([^"\']+)',
            r'(?i)["\'](?:embed|player|iframe|playerurl|embedurl)[\w-]*["\']?\s*[:=]\s*["\']([^"\']+)',
            r'(?i)<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+content=["\'][^"\']*url=([^"\';>]+)',
        ]
        for p in patterns: vals += re.findall(p,body)
    return unique_urls([absolute(x,base) for x in vals if x and not x.lower().startswith(('javascript:','#'))])


def extract_iframes(doc, base):
    vals=re.findall(r'(?is)<iframe\b[^>]*?\bsrc\s*=\s*["\']([^"\']+)', doc)
    return unique_urls([absolute(v,base) for v in vals])


def _playback_referer(media_url, page_ref):
    """Choose the Referer that CDNs will accept for segment downloads.

    Many upstream CDNs (e.g. webtvstream.bhtelecom.ba via gledamsport.com)
    reject requests whose Referer is jagledam.cc (HTTP 403).  When the media
    host differs from the player-page host, use the media origin instead.
    """
    try:
        mhost = urllib.parse.urlparse(media_url).netloc.lower()
        phost = urllib.parse.urlparse(page_ref or '').netloc.lower()
    except Exception:
        return page_ref
    if mhost and phost and mhost != phost and not mhost.endswith('.'+phost) and not phost.endswith('.'+mhost):
        scheme = urllib.parse.urlparse(media_url).scheme or 'https'
        return '%s://%s/' % (scheme, mhost)
    return page_ref


def resolve(choice_url, referer):
    """Resolve a stream choice to a DIRECT media URL (m3u8/mpd/mp4).

    Never returns an HTML page URL: Kodi's FFmpeg cannot probe HTML, which is
    exactly what produced "Open - error probing input format" when the raw
    /kNN/ embed URL was handed to the player.

    Raises ResolveError when no media can be found so the caller can re-scrape
    a fresh stream link (JaGledam tokens are short-lived).
    """
    current=choice_url; ref=referer
    for depth in range(8):
        if MEDIA_EXT_RE.search(current):
            return current, _playback_referer(current, ref), None, 'full'

        try:
            doc, final=fetch(current, ref)
        except Exception as e:
            raise ResolveError('Could not load player page: %s' % e)

        # Anti-hotlink behaviour: a /kNN/token requested without a valid
        # session redirects to the JaGledam homepage. That means the token
        # expired or the session was rejected -> caller must re-scrape.
        if _is_home(final):
            raise ResolveError(
                'Stream token expired or rejected (redirected to homepage)')

        page_drm=drm_config(doc, final)

        medias=media_urls(doc, final)
        best=None
        for m in medias:
            ok, status, ctype, snippet, mode = check_media(m, final)
            enc=manifest_encrypted(snippet) if ok else None
            _dbg('candidate %s -> HTTP %s (%s, encrypted=%s, mode=%s)' % (m, status, ctype, enc, mode))
            if ok and not enc:
                _dbg('resolved media: %s' % m)
                return m, _playback_referer(m, final), page_drm, mode
            if ok and best is None:
                best=(m, enc, snippet, mode)
        if best is not None:
            # Only encrypted candidates remain. Merge manifest info (scheme,
            # HLS #EXT-X-KEY license URI) with whatever the player page gave.
            m, enc, snippet, mode = best
            drm=dict(page_drm) if page_drm else {}
            if enc and enc != 'aes-128':
                lic_type=_LICENSE_TYPE_BY_SCHEME.get(enc)
                if lic_type and 'scheme' not in drm:
                    drm['scheme']=lic_type
            key_uri=manifest_key_uri(snippet)
            if key_uri and not drm.get('license'):
                drm['license']=urllib.parse.urljoin(m, key_uri)
            usable=drm.get('keys') or drm.get('license')
            if enc and enc != 'aes-128' and not usable:
                # DRM-geschuetzt, aber keine Lizenz auffindbar: den naechsten
                # Stream-Link der Kanalseite probieren (ResolveError-Fallback
                # in plugin.py).
                raise ResolveError(
                    'Stream DRM-geschuetzt (%s), keine Lizenz-URL gefunden' % enc)
            play_ref = _playback_referer(m, final)
            _dbg('falling back to candidate: %s (drm=%s, play_ref=%s)' % (m, drm, play_ref))
            return m, play_ref, (drm or None), mode
        if medias:
            # Alle gefundenen Kandidaten sind unerreichbar (Timeout/403):
            # ResolveError -> plugin.py probiert den naechsten Stream-Link.
            raise ResolveError(
                'Stream-Server nicht erreichbar (Timeout/HTTP-Fehler) - '
                'eventuell Geo-Block')

        candidates=player_candidates(doc, final)
        candidates=[u for u in candidates if u not in (current, final, BASE, BASE+'/')]
        if not candidates:
            _dbg('no media in page %s; snippet: %s' % (final, doc[:400]))
            raise ResolveError(
                'No playable media found on player page (JavaScript-protected embed)')
        ref=final; current=candidates[0]
    raise ResolveError('Too many nested player frames')


# ---------------------------------------------------------------------------
# Channel discovery (unchanged logic from v1.0.4)
# ---------------------------------------------------------------------------

def country_candidates(doc):
    out=[]
    for text, href, attrs in links_from(doc):
        low=text.lower()
        for label, code, keys in COUNTRIES:
            if any(k in low for k in keys):
                u=absolute(href)
                if u.startswith(BASE) and u not in [x[2] for x in out]: out.append((label, code, u))
    return out


def channel_links(doc, page_url):
    found=[]; seen=set()
    for text, href, attrs in links_from(doc):
        u=absolute(href, page_url)
        low=(text+' '+u).lower()
        # Channel pages on JaGledam conventionally use *-uzivo-stream URLs.
        if 'uzivo-stream' not in low: continue
        if u in seen: continue
        name=dclean(text)
        if not name:
            slug=urllib.parse.urlparse(u).path.rsplit('/',1)[-1]
            name=re.sub(r'-uzivo-stream.*$', '', slug, flags=re.I).replace('-', ' ')
        name=re.sub(r'\s+\d+(?:\.\d+)?[mk]$', '', name, flags=re.I).strip()
        if name:
            seen.add(u); found.append({'name':name,'url':u})
    return found


def _country_tokens(country_code):
    """Tokens used by JaGledam's client-side country filter (#BIH, #RS, ...)."""
    code=(country_code or '').upper()
    aliases={
        'BIH': ('BIH','BH','BOSNA','BOSNIA'),
        'HR': ('HR','HRVATSKA','CROATIA'),
        'RS': ('RS','SRB','SRBIJA','SERBIA'),
        'SLO': ('SLO','SI','SLOVENIJA','SLOVENIA'),
        'CG': ('CG','ME','CRNA-GORA','CRNA_GORA','MONTENEGRO'),
        'MK': ('MK','MAKEDONIJA','MACEDONIA'),
        'KS': ('KS','XK','KOSOVO'),
    }
    return aliases.get(code,(code,))


VOID_TAGS = set(('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'))


def _codes_in_attrs(attrs):
    """Return country codes explicitly present in structural attributes."""
    aliases = {
        'BIH': ('BIH','BH'), 'HR': ('HR','HRV'), 'RS': ('RS','SRB'),
        'SLO': ('SLO','SI'), 'CG': ('CG','ME'), 'MK': ('MK',), 'KS': ('KS','XK')
    }
    vals=[]
    for k,v in attrs.items():
        k=(k or '').lower()
        if k in ('id','class','data-country','data-filter','data-category','data-group','data-region','data-target'):
            vals += re.findall(r'[A-Za-z0-9_-]+', str(v or '').upper())
    toks=set(vals)
    found=[]
    for code,names in aliases.items():
        if any(n in toks for n in names): found.append(code)
    return found


class CountryChannelParser(HTMLParser):
    """Stateful parser for JaGledam's homepage country-filter DOM.

    Country markers are accepted only from structural attributes on the current
    element/ancestors.  Text and arbitrary nearby HTML are intentionally ignored.
    This prevents country navigation and neighbouring cards from contaminating a
    channel's classification.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack=[]
        self.channels=[]
        self.current_link=None

    def handle_starttag(self, tag, attrs):
        tag=tag.lower(); d=dict(attrs)
        parent_codes=self.stack[-1][2] if self.stack else set()
        own=set(_codes_in_attrs(d))
        codes=own if own else set(parent_codes)
        if tag not in VOID_TAGS:
            self.stack.append((tag,d,codes))
        if tag=='a' and d.get('href') and 'uzivo-stream' in d.get('href','').lower():
            self.current_link={'href':d['href'], 'text':[], 'codes':set(codes)}

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag.lower() not in VOID_TAGS: self.handle_endtag(tag)

    def handle_data(self, data):
        if self.current_link is not None: self.current_link['text'].append(data)

    def handle_endtag(self, tag):
        tag=tag.lower()
        if tag=='a' and self.current_link is not None:
            self.channels.append(self.current_link); self.current_link=None
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i][0]==tag:
                del self.stack[i:]
                break


def channels_from_homepage(doc, country_code):
    p=CountryChannelParser(); p.feed(doc)
    want=(country_code or '').upper()
    out=[]; seen=set()
    for item in p.channels:
        if want not in item.get('codes',set()): continue
        u=absolute(item['href'])
        if u in seen: continue
        name=dclean(' '.join(item.get('text',[])))
        name=re.sub(r'\s+\d+(?:\.\d+)?[mk]$', '', name, flags=re.I).strip()
        if not name:
            slug=urllib.parse.unquote(urllib.parse.urlparse(u).path.rsplit('/',1)[-1])
            name=re.sub(r'-uzivo-stream.*$', '', slug, flags=re.I).replace('-', ' ')
        if name:
            seen.add(u); out.append({'name':name,'url':u})
    return out


COUNTRY_ENDPOINTS = {
    'BIH': 1,
    'HR': 2,
    'RS': 3,
    'SLO': 4,
    'CG': 5,
    'MK': 6,
    'KS': 7,
}


class PortfolioParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.channels=[]
        self.card=None
        self.in_title=False

    def handle_starttag(self, tag, attrs):
        tag=tag.lower(); d=dict(attrs)
        classes=set((d.get('class') or '').split())
        if tag=='a' and d.get('href') and 'portfolio-item' in classes:
            self.card={'url':d['href'], 'name_parts':[], 'image':''}
        elif self.card is not None and tag=='h3' and 'cbp-ig-title' in classes:
            self.in_title=True
        elif self.card is not None and tag=='img' and not self.card['image']:
            self.card['image']=d.get('src','')

    def handle_data(self, data):
        if self.card is not None and self.in_title:
            self.card['name_parts'].append(data)

    def handle_endtag(self, tag):
        tag=tag.lower()
        if tag=='h3':
            self.in_title=False
        elif tag=='a' and self.card is not None:
            name=dclean(' '.join(self.card['name_parts']))
            u=absolute(self.card['url'])
            if name and 'uzivo-stream' in u.lower():
                self.channels.append({'name':name, 'url':u, 'image':absolute(self.card['image']) if self.card['image'] else ''})
            self.card=None; self.in_title=False


def parse_country_channels(doc):
    p=PortfolioParser(); p.feed(doc)
    out=[]; seen=set()
    for ch in p.channels:
        if ch['url'] in seen: continue
        seen.add(ch['url']); out.append(ch)
    return out


def discover_channels(country_code):
    code=(country_code or '').upper()
    endpoint_id=COUNTRY_ENDPOINTS.get(code)
    if endpoint_id is None:
        raise ValueError('Unknown country code: '+code)
    endpoint=BASE + '/con.php?id=' + str(endpoint_id)
    doc, final=fetch(endpoint, BASE + '/')
    return parse_country_channels(doc)


def stream_choices(channel_url):
    doc, final=fetch(channel_url, BASE+'/')
    choices=[]; seen=set()
    for text, href, attrs in links_from(doc):
        if re.search(r'(?i)stream\s*link\s*\d+', text):
            u=absolute(href, final)
            if u not in seen:
                seen.add(u); choices.append({'name':text, 'url':u, 'referer':final})
    # The currently selected JaGledam player is normally also the iframe whose
    # src equals one of the Stream Link targets. Keep iframe-only channels usable.
    if not choices:
        srcs=extract_iframes(doc, final)
        for i,u in enumerate(srcs,1): choices.append({'name':'Stream %d'%i,'url':u,'referer':final})
    return choices
